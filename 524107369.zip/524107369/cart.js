// Cart Management System - Hệ thống quản lý giỏ hàng

// Lấy giỏ hàng từ localStorage
function getCart() {
    return JSON.parse(localStorage.getItem('cart')) || [];
}

// Lưu giỏ hàng vào localStorage
function saveCart(cart) {
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartBadge();
}

// Thêm sản phẩm vào giỏ hàng
function addToCart(product) {
    const cart = getCart();
    const existingItem = cart.find(item => item.id === product.id);
    
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({
            id: product.id,
            name: product.name,
            price: product.price,
            image: product.image,
            quantity: 1
        });
    }
    
    saveCart(cart);
    showToast('Đã thêm sản phẩm vào giỏ hàng!');
}

// Cập nhật badge số lượng giỏ hàng
function updateCartBadge() {
    const cart = getCart();
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    const badge = document.querySelector('.cart-badge');
    
    if (badge) {
        badge.textContent = totalItems;
        badge.style.display = totalItems > 0 ? 'inline' : 'none';
    }
}

// Hiển thị thông báo toast
function showToast(message) {
    // Tạo toast element nếu chưa có
    let toastContainer = document.querySelector('.toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.className = 'toast-container position-fixed top-0 end-0 p-3';
        document.body.appendChild(toastContainer);
    }
    
    const toastHtml = `
        <div class="toast" role="alert">
            <div class="toast-header">
                <i class="fas fa-shopping-cart text-primary me-2"></i>
                <strong class="me-auto">Thông báo</strong>
                <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
            </div>
            <div class="toast-body">
                ${message}
            </div>
        </div>
    `;
    
    toastContainer.innerHTML = toastHtml;
    const toastElement = toastContainer.querySelector('.toast');
    const toast = new bootstrap.Toast(toastElement);
    toast.show();
}

// Khởi tạo khi trang được tải
document.addEventListener('DOMContentLoaded', function() {
    updateCartBadge();
    
    // Thêm event listener cho tất cả nút "Thêm vào giỏ"
    const addToCartButtons = document.querySelectorAll('.btn-add-to-cart');
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            const productCard = this.closest('.card');
            const product = {
                id: this.dataset.productId || Date.now().toString(),
                name: productCard.querySelector('.card-title').textContent.trim(),
                price: parseInt(productCard.querySelector('.text-primary').textContent.replace(/[^\d]/g, '')),
                image: productCard.querySelector('img').src
            };
            
            addToCart(product);
        });
    });
});