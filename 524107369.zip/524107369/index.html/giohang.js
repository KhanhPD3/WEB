// Giỏ hàng JavaScript

// Tải giỏ hàng từ localStorage và hiển thị
function loadCartItems() {
    const cart = getCart();
    const cartContainer = document.querySelector('.card-body');
    const emptyCart = document.getElementById('emptyCart');
    
    if (cart.length === 0) {
        cartContainer.innerHTML = '';
        emptyCart.style.display = 'block';
        return;
    }
    
    emptyCart.style.display = 'none';
    let cartHTML = '';
    cart.forEach((item, index) => {
        cartHTML += `
            <div class="cart-item" data-item-id="${item.id}">
                <div class="row align-items-center">
                    <div class="col-md-2">
                        <img src="${item.image}" alt="${item.name}" class="cart-item-image">
                    </div>
                    <div class="col-md-4">
                        <h6 class="cart-item-title">${item.name}</h6>
                        <p class="cart-item-desc">Size: M, Màu: Đa dạng</p>
                    </div>
                    <div class="col-md-2">
                        <div class="quantity-control">
                            <button class="btn btn-sm btn-outline-secondary" onclick="decreaseQuantity('${item.id}')">−</button>
                            <input type="number" class="form-control quantity-input" id="qty${item.id}" value="${item.quantity}" min="1">
                            <button class="btn btn-sm btn-outline-secondary" onclick="increaseQuantity('${item.id}')">+</button>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <span class="cart-item-price">${formatCurrency(item.price)}</span>
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-sm btn-outline-danger" onclick="removeItem('${item.id}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;
    });
    
    cartContainer.innerHTML = cartHTML;
    updateTotal();
}

// Tăng số lượng sản phẩm
function increaseQuantity(itemId) {
    const cart = getCart();
    const item = cart.find(item => item.id === itemId);
    if (item) {
        item.quantity += 1;
        saveCart(cart);
        document.getElementById(`qty${itemId}`).value = item.quantity;
        updateTotal();
    }
}

// Giảm số lượng sản phẩm
function decreaseQuantity(itemId) {
    const cart = getCart();
    const item = cart.find(item => item.id === itemId);
    if (item && item.quantity > 1) {
        item.quantity -= 1;
        saveCart(cart);
        document.getElementById(`qty${itemId}`).value = item.quantity;
        updateTotal();
    }
}

// Xóa sản phẩm khỏi giỏ hàng
function removeItem(itemId) {
    if (confirm('Bạn có chắc chắn muốn xóa sản phẩm này khỏi giỏ hàng?')) {
        const cart = getCart();
        const updatedCart = cart.filter(item => item.id !== itemId);
        saveCart(updatedCart);
        
        const cartItem = document.querySelector(`[data-item-id="${itemId}"]`);
        cartItem.style.animation = 'fadeOut 0.5s ease-in-out';
        setTimeout(() => {
            loadCartItems();
        }, 500);
    }
}

// Cập nhật tổng tiền
function updateTotal() {
    const cart = getCart();
    let subtotal = 0;
    
    cart.forEach(item => {
        subtotal += item.price * item.quantity;
    });
    
    const shipping = 30000;
    const discount = 50000;
    const total = subtotal + shipping - discount;
    
    document.getElementById('subtotal').textContent = formatCurrency(subtotal);
    document.getElementById('total').textContent = formatCurrency(total);
}

// Định dạng tiền tệ
function formatCurrency(amount) {
    return new Intl.NumberFormat('vi-VN').format(amount) + 'đ';
}

// Áp dụng mã giảm giá
function applyCoupon() {
    const couponCode = document.getElementById('couponCode').value.trim();
    
    if (couponCode === '') {
        alert('Vui lòng nhập mã giảm giá!');
        return;
    }
    
    const validCoupons = {
        'KIDDY10': 10,
        'SALE20': 20,
        'NEWBIE15': 15
    };
    
    if (validCoupons[couponCode.toUpperCase()]) {
        const discountPercent = validCoupons[couponCode.toUpperCase()];
        alert(`Áp dụng mã giảm giá thành công! Giảm ${discountPercent}%`);
        updateTotal();
    } else {
        alert('Mã giảm giá không hợp lệ!');
    }
}

// Thanh toán
function checkout() {
    const cart = getCart();
    
    if (cart.length === 0) {
        alert('Giỏ hàng của bạn đang trống!');
        return;
    }
    
    if (confirm('Bạn có chắc chắn muốn thanh toán?')) {
        alert('Chuyển hướng đến trang thanh toán...');
    }
}

// Animation fadeOut
const style = document.createElement('style');
style.textContent = `
    @keyframes fadeOut {
        from {
            opacity: 1;
            transform: translateX(0);
        }
        to {
            opacity: 0;
            transform: translateX(-100%);
        }
    }
`;
document.head.appendChild(style);

// Khởi tạo khi trang được tải
document.addEventListener('DOMContentLoaded', function() {
    loadCartItems();
});